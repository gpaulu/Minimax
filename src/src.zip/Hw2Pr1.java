

public class Hw2Pr1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double delta = 0.125;
		final double SMALLSTEP = delta/2048;
		for(double x=1; x<=5; x++){
			System.out.println("x: " + x);
			double prevX = 0;
			double prevY = 0;
			double curX = x;
			double curY = f(x);
			boolean atMax = false;
			while(!atMax){
				prevX = curX;
				prevY = curY;
				curX = prevX + delta;
				curY = f(curX);
				if(curY < prevY){
					if(Math.abs(delta) < SMALLSTEP){
						atMax = true;
					}
					else{
						delta = -1 * (delta/8);
					}
				}
			}
			System.out.println("Max: " + prevY);
		}
	}
	
	public static double f(double x){
		return (Math.sin(x*x*x))/x;
	}

}
