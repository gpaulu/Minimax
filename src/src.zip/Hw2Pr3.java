//uses WordSolver.java
import java.util.Scanner;


public class Hw2Pr3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("First Word:");
		Scanner kb = new Scanner(System.in);
		String top = kb.nextLine();
		System.out.println("Second Word:");
		String middle = kb.nextLine();
		System.out.println("Final Word:");
		String bottom = kb.nextLine();
		kb.close();
		
		WordSolver game = new WordSolver(top,middle,bottom);
		game.solve();
		game.printSolution();
	}
}
