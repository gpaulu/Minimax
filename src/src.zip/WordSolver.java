import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class WordSolver {
	private List<Character> letters;
	private List<List<Integer>> possible;
	private List<Integer> solution;
	HashMap<Character,Integer> charToInt;
	private String top;
	private String middle;
	private String bottom;
	WordSolver(String top, String middle, String bottom){
		letters = new ArrayList<Character>();
		for(int i=0; i<top.length(); i++){
			if(!letters.contains(top.charAt(i))){
				letters.add(top.charAt(i));
			}
		}
		for(int i=0; i<middle.length(); i++){
			if(!letters.contains(middle.charAt(i))){
				letters.add(middle.charAt(i));
			}
		}
		for(int i=0; i<bottom.length(); i++){
			if(!letters.contains(bottom.charAt(i))){
				letters.add(bottom.charAt(i));
			}
		}
		possible = new ArrayList<List<Integer>>();
		for(int j=0; j<letters.size(); j++){
			possible.add(new ArrayList<Integer>());
			for(int i=0; i<=9; i++){
				possible.get(j).add(i);
			}
		}
		charToInt = new HashMap<Character,Integer>();
		for(int i=0; i<letters.size(); i++){
			charToInt.put(letters.get(i), i);
		}
		this.top = new StringBuffer(top).reverse().toString();
		this.middle = new StringBuffer(middle).reverse().toString();
		this.bottom = new StringBuffer(bottom).reverse().toString();
	}
	
	public boolean solve(){
		doLogic();
		return recSearch(new ArrayList<Integer>());
	}
	
	//remember: strings are reversed
	private void doLogic(){
		//#1
		//last digit cannot be 0
		possible.get(charToInt.get(top.charAt(top.length()-1))).remove(new Integer(0));
		possible.get(charToInt.get(middle.charAt(middle.length()-1))).remove(new Integer(0));
		possible.get(charToInt.get(bottom.charAt(bottom.length()-1))).remove(new Integer(0));
		//#2
		//Duplicates must add to even.
		if(top.charAt(0) == middle.charAt(0)){
			for(int i=1; i<=9; i+=2){
				possible.get(charToInt.get(bottom.charAt(0))).remove(new Integer(i));
			}
		}
		//#3
		//if bottom is longest, last letter must be 1
		if(bottom.length() > top.length() && bottom.length() > middle.length()){
			possible.get(charToInt.get(bottom.charAt(bottom.length()-1))).clear();
			possible.get(charToInt.get(bottom.charAt(bottom.length()-1))).add(1);
		}
		//#4
		//if there's no carry at the end, sum of last must be < 5
		else if(top.length() == middle.length() && top.charAt(top.length()-1) == middle.charAt(middle.length()-1)){
			for(int i=5;i<10;i++){
				possible.get(charToInt.get(top.charAt(top.length()-1))).remove(new Integer(i));
				possible.get(charToInt.get(middle.charAt(middle.length()-1))).remove(new Integer(i));
			}
		}
	}
	
	private boolean recSearch(List<Integer> list){
		if(list.size() == possible.size()){
			boolean sol = isSolution(list);
			if(sol){
				solution = list;
			}
			return sol;
		}
		for(int i=0; i<possible.get(list.size()).size(); i++){
			if(!list.contains(possible.get(list.size()).get(i))){ //all letters are unique
				list.add(possible.get(list.size()).get(i));
				if(recSearch(list)){
					return true;
				}
				list.remove(list.size()-1);
			}
		}
		return false;
	}
	
	private boolean isSolution(List<Integer> list){
		int t = wordToInt(list,0);
		int m = wordToInt(list,1);
		int b = wordToInt(list,2);
		return b == (t+m);
	}
	
	private int wordToInt(List<Integer> list, int numWord){
		int total=0;
		String string;
		if(numWord == 0){
			string = top;
		}
		else if(numWord == 1){
			string = middle;
		}
		else{
			string = bottom;
		}
		for(int i=0; i<string.length(); i++){
			total += ((int)Math.pow(10.0, (double)i))*list.get(charToInt.get(string.charAt(i)));
		}
		return total;
	}
	
	public void printSolution(){
		if(solution.size() > 0){
			System.out.println("Solution:\n\t" + wordToInt(solution,0) + "\n+\t" + wordToInt(solution,1) + "\n---------------\n\t" + wordToInt(solution,2));
		}
		else{
			System.out.println("No Solution");
		}
	}
}
