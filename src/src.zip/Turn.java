
public enum Turn{
	MIN, MAX, LEAF
}